// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    let t_main = std::time::Instant::now();

    // Capture cwd immediately — before Tauri or any library changes it.
    let cwd = std::env::current_dir()
        .ok()
        .map(|p| p.to_string_lossy().to_string());

    // Support `tauri-explorer /some/path` CLI argument (flags like
    // --file-chooser-portal are not paths).
    let cli_path = std::env::args().nth(1).filter(|a| !a.starts_with("--"));
    let portal_mode = std::env::args().any(|a| a == "--file-chooser-portal");

    // On macOS, launching from Finder/DMG sets cwd to "/" which is not useful.
    // Fall back to the home directory in that case.
    let cwd = cwd.filter(|p| p != "/");

    let launch_dir = cli_path.or(cwd);

    // Fork to background so the launching terminal is freed.
    // On Windows, the windows_subsystem attribute already handles this.
    // Skip in debug/dev builds so `tauri dev` stays in the foreground with logs.
    // macOS: fork() is not safe after Cocoa/AppKit initialization — it breaks
    // WKWebView's XPC connections, causing blank windows. Use `open -a` to launch
    // the .app bundle detached from the terminal instead.
    // Portal mode must not fork: D-Bus activation tracks the spawned
    // process, which has to be the one acquiring the bus name.
    #[cfg(all(target_os = "linux", not(debug_assertions)))]
    if !portal_mode {
        unsafe {
            let pid = libc::fork();
            if pid > 0 {
                // Parent — exit immediately to free the terminal.
                libc::_exit(0);
            }
            if pid == 0 {
                // Child — start a new session so we're fully detached.
                libc::setsid();
            }
            // pid < 0: fork failed, just continue in the original process.
        }
    }
    #[cfg(not(all(target_os = "linux", not(debug_assertions))))]
    let _ = portal_mode;

    #[cfg(debug_assertions)]
    eprintln!("[Perf] main() pre-run: {:?}", t_main.elapsed());
    tauri_explorer_lib::run(launch_dir)
}
